<!DOCTYPE html>
<html>
<body>

<?php
echo "this is php script  by vinod version-2!";
?>

</body>
</html>